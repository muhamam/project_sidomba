

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php echo $__env->make('layouts.sidebarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col">
        <div class="row">
            <div class="col mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-row">
                            <a class="mt-3" href="<?php echo e(route('account.index')); ?>" style="color: #000;">
                                <p class="marker">Biodata</p>
                            </a>
                            <a class="ml-5 mt-3" href="<?php echo e(route('password.index')); ?>" style="color: #000;">
                                <p class="marker"> Ubah Password</p>
                            </a>
                            <a class="ml-5 mt-3" href="<?php echo e(route('address.index')); ?>" style="color: #000;">
                                <p class="marker"> Alamat</p>
                            </a>
                        </div>

                        <div class="e-profile mt-1">

                            <!-- sebelum di ubah pasword -->
                            <div class="col-4" style="background-color:#ED818C ;">

                                <h6> <b>PERHATIAN</b> : Anda hanya bisa mengubah password sebanyak 2 kali lagi </h6>
                            </div>
                            <!-- sesudah di ubah pasword -->
                            <div class="col-4" style="background-color:#44F060 ;">
                                <span class="iconify" data-icon="akar-icons:check" data-width="30"
                                    data-height="30"></span>
                                <h6>Password berhasil diganti. Anda bisa mengganti password sebanyak 1 kali lagi.
                                </h6>
                            </div>
                            <div class="mb-3">
                                <label class="form-label" style="margin-right: 300px;"><b> Password Lama</b></label>
                                <input type="password" id="berat" class="form-control"
                                    placeholder="Ketikkan password lama anda disini">

                            </div>

                            <div class="mb-3">
                                <label class="form-label" style="margin-right: 300px;"><b>Password Baru </b>
                                </label>
                                <input type="password" id="berat" class="form-control"
                                    placeholder="Ketikkan Password Baru anda disini">

                            </div>
                            <div class="mb-3">
                                <label for="harga" class="form-label" style="margin-right: 250px;"><b> Konfirmasi
                                        Password
                                        Baru </b></label>
                                <input name="harga" type="password" id="harga" class="form-control"
                                    placeholder="Ketikkan password baru anda disini">
                                <!-- <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
                            </div>

                            <button type="submit" class="btn btn-primary mt-2">Ganti Password</button>


                        </div>
                    </div>
                </div>

            </div>
        </div>
        </ul>

    </div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bulan mei\kuliah\project pak firmasnyah\project_sidomba\resources\views/user/ubah_password.blade.php ENDPATH**/ ?>