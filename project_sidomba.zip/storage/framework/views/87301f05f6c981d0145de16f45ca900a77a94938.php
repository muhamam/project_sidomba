

<?php $__env->startSection('content'); ?>

<div class="col-md-6 mx-auto mt-5 mb-5">
    <form>
        <center>
            <div class="PHOTO">
                <img src="img/domba_input.png" alt="" style="width: 81; height:81px;">
            </div>

            <fieldset>

                <legend>Input Data Domba </legend>
                <input type="hidden" name="id">
                <input type="hidden" name="nama_peternak">
                <input type="hidden" name="namafile">
        </center>
        <div class="mb-3">
            <label for="jenis" class="form-label"> ID Domba (Sesuai RFID/Input Manual)</label>
            <input name="jenis" type="text" id="jenis" class="form-control"
                placeholder="JENIS DOMBA APA YANG KMU PUNYA?">
            <!-- <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
        </div>
        <div class="mb-3">

            <label for="jenis" class="form-label">Tanggal Lahir Domba (Umur Domba akan ditentukan dari tanggal
                lahirnya)</label>
            <input name="jenis" type="text" id="jenis" class="datepicker form-control" placeholder="TGL/BULAN/TAHUN">


            <!-- <?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
        </div>
        <div class="mb-3">
            <label for="berat" class="form-label">Berat Domba Saat Ini (Kg)</label>
            <input name="berat" type="text" id="berat" class="form-control" placeholder="MASUKAN BERAT DOMBAMU!">
            <!-- <?php $__errorArgs = ['berat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
        </div>

        <div class="mb-3">
            <label for="kelamin" class="form-label">JENIS KELAMIN DOMBA</label>
            <select id="kelamin" class="form-select form-control" name="kelamin">
                <option value="betina">
                    <!-- <?php echo e(old('kelamin') == 'betina' ? 'selected' : ''); ?> -->
                    BETINA
                </option>
                <option value="betina">
                    <!-- <?php echo e(old('kelamin') == 'Jantan' ? 'selected' : ''); ?> -->
                    JANTAN
                </option>
            </select>
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Jenis Domba</label>
            <input name="harga" type="text" id="harga" class="form-control" placeholder="masukan jenis dombamu">
            <!-- <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
        </div>
        <div class="form-group">
            <label for="berkas" class="form-label">Foto Domba (max 2mb)</label>
            <input type="file" name="image" id="harga" class="image form-control">
            <!-- <?php $__errorArgs = ['berkas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
        </div>
        <center>
            <button type="submit" class="btn btn-primary mt-2">Submit</button>
        </center>
        </fieldset>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bulan mei\kuliah\project pak firmasnyah\project_sidomba\project_sidomba\resources\views/peternak/input_domba.blade.php ENDPATH**/ ?>