

<?php $__env->startSection('content'); ?>



<div class="body-login2 col-12  ">

    <div class="body-login3 mt-5 rounded ">
        <center>

            <div class="">
                <img src="../img/logodomba.png" alt="" style="width: 77px; height: 77px;">

                <h3 class="" style="color:black">CARIBI </h3>
            </div>
            <div class="box-1   mt-5">
                <iconify-icon icon="ic:outline-password" width="25" height="25" style="color:green"></iconify-icon>
                <h2>
                    <a style="color: Black;">Masukkan Password</a>
                </h2>
            </div>
        </center>
        <div class=" box-2 d-flex flex-column ">
            <div class="mt-1">
                <div class="semua-login d-flex flex-column p-5">

                    <?php echo csrf_field(); ?>
                    <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="mb-2">
                        <h6 style="color:black">Password</h6>
                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                            aria-describedby="emailHelp" name="password" placeholder="Masukan Password Baru">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-2">
                        <h6 style="color:black">Konfirmasi Password</h6>
                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="password" name="password" placeholder="Konfirmasi Password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                </div>
                <div class="daftar ">
                    <a type="submit" class="btn btn-primary tombol-login " href="#" style="width:200px;">
                        <?php echo e(__('Masukan Password')); ?>

                    </a>
                </div>
            </div>
        </div>

    </div>
</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bulan mei\kuliah\project pak firmasnyah\project_sidomba\project_sidomba\resources\views/auth/bikin.blade.php ENDPATH**/ ?>