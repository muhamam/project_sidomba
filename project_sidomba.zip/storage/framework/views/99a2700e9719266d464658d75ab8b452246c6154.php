

<?php $__env->startSection('content'); ?>
<div class="row  d-flex">
    <?php echo $__env->make('layouts.sidebarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ftco-section col" style="margin-top: 100px; ">
        <div class="container " style="background-color: white; border-radius:15px;">
            <div class="d-flex flex-row   ml-3 mb-3 mt-3">
                <a class="mt-3" href="<?php echo e(route('account.index')); ?>" style="color: #000;">
                    <h5>Biodata</h5>
                </a>
                <a class="ml-5 mt-3" href="<?php echo e(route('password.index')); ?>" style="color: #000;">
                    <h5> Ubah Password</h5>
                </a>
                <a class="ml-5 mt-3" href="<?php echo e(route('address.index')); ?>" style="color: #000;">
                    <h5> Alamat</h5>
                </a>
            </div>
            <div class=" mb-3" style="width: 100%; height:1px; background-color: #3A8BCD; "></div>
            <div class="kabeh rounded-lg" style="height: 380px; ">
                <center>
                    <form class="col-12" action="<?php echo e(route('contact.index')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <h6>Nomor Handphone</h6>
                    <div class="input-group mb-3 col-6">

                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">+62</span>
                        </div>
                        <input type="text" class="form-control <?php $__errorArgs = ['no_HP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_HP" name="no_HP" value="<?php echo e(old('no_HP') ?? Auth::user()->no_HP); ?>">
                        <?php $__errorArgs = ['no_HP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <h6>Email</h6>
                    <div class="input-group mb-3 col-6">

                        <input type="email" class="form-control" placeholder="Email" value="<?php echo e(Auth::user()->email); ?>"
                            disabled>
                    </div>

                    <center>
                        <button type="submit" class="btn btn-primary mt-2">Update Kontak</button>
                    </center>
                    </form>
                </center>
            </div>
            <br>
        </div>
    </section>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bulan mei\kuliah\project pak firmasnyah\project_sidomba\resources\views/user/edit_kontak.blade.php ENDPATH**/ ?>