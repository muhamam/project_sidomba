@extends('layouts.user')

@section('content')

<div class="row ">
    <div class=" col-md-3" style="margin-left: 30px; margin-top:120px;">
        <div class="row">
            <span class="iconify col-2" data-icon="ant-design:filter-outlined" data-width="35" data-height="35"></span>
            <h4 class="col">Filter</h4>
        </div>
        <div class=" bg-light  ">

            <h6 class="ml-4"><b> Jenis Domba</b></h6>
            <div class="dropdown ml-4">
                <a class="btn  dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown"
                    aria-expanded="false" style="width: 250px; border: 1px solid #000000;">
                    Semua Domba
                </a>

                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <li><a class="dropdown-item" href="#">Action</a></li>
                    <li><a class="dropdown-item" href="#">Another action</a></li>
                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                </ul>
            </div>
            <center>
                <div class="dotted mb-3 mt-2 col-md-11"></div>
            </center>
            <h6 class="ml-4"><b> Semua Lokasi</b></h6>
            <center>
                <div class="input-group flex-nowrap rounded mr-3" style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Semua Lokasi" aria-label="Username"
                        aria-describedby="addon-wrapping">

                </div>
            </center>
            <center>
                <div class="dotted mb-3 mt-2 col-md-11"></div>
            </center>
            <h6 class="ml-4"><b>Harga Investasi</b></h6>
            <center>
                <div class="input-group flex-nowrap rounded mr-3" style="width:  255px; border: 1px solid #000000;">
                    <span class="input-group-text" id="addon-wrapping">Rp.</span>
                    <input type="text" class="form-control" placeholder="Harga Minimun" aria-label="Username"
                        aria-describedby="addon-wrapping">

                </div>
                <div class="input-group flex-nowrap rounded mr-3 mt-2"
                    style="width:  255px; border: 1px solid #000000;">
                    <span class="input-group-text" id="addon-wrapping">Rp.</span>
                    <input type="text" class="form-control" placeholder="Harga Maximum" aria-label="Username"
                        aria-describedby="addon-wrapping">

                </div>
            </center>
            <center>
                <div class="dotted mb-3 mt-2 col-md-11"></div>
            </center>
            <h6 class="ml-4"><b>Bagi Hasil</b></h6>
            <center>
                <div class="input-group flex-nowrap rounded mr-3" style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Persentase Peternakan" aria-label="Username"
                        aria-describedby="addon-wrapping">
                    <span class="input-group-text" id="addon-wrapping">%</span>

                </div>
                <div class="input-group flex-nowrap rounded mr-3 mt-2"
                    style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Persentase Investo" aria-label="Username"
                        aria-describedby="addon-wrapping">
                    <span class="input-group-text" id="addon-wrapping">%</span>
                </div>
            </center>
            <center>
                <div class="dotted mb-3 mt-2 col-md-11"></div>
            </center>
            <h6 class="ml-4"><b> Jenis Kelamin</b></h6>
            <center>
                <div class="form-check ">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                        Jantan
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked>
                    <label class="form-check-label" for="flexCheckChecked">
                        Betina
                    </label>
                </div>
            </center>
            <center>
                <div class="dotted mb-3 mt-2 col-md-11"></div>
            </center>
            <h6 class="ml-4"><b>Berat</b></h6>
            <center>
                <div class="input-group flex-nowrap rounded mr-3" style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Berat Minimum" aria-label="Username"
                        aria-describedby="addon-wrapping">
                    <span class="input-group-text" id="addon-wrapping">Kg</span>

                </div>
                <div class="input-group flex-nowrap rounded mr-3 mt-2"
                    style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Berat Maksimum" aria-label="Username"
                        aria-describedby="addon-wrapping">
                    <span class="input-group-text" id="addon-wrapping">Kg</span>
                </div>
            </center>
            <center>
                <div class="dotted mb-3 mt-2 col-md-11"></div>
            </center>
            <h6 class="ml-4"><b>Umur</b></h6>
            <center>
                <div class="input-group flex-nowrap rounded mr-3 " style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Umur Minimum" aria-label="Username"
                        aria-describedby="addon-wrapping">
                    <span class="input-group-text" id="addon-wrapping">Thn</span>

                </div>
                <div class="input-group flex-nowrap rounded mr-3 mt-2 "
                    style="width:  255px; border: 1px solid #000000;">

                    <input type="text" class="form-control" placeholder="Umur Maksimum" aria-label="Username"
                        aria-describedby="addon-wrapping">
                    <span class="input-group-text" id="addon-wrapping">Thn</span>
                </div>
            </center>
            <br>






        </div>

    </div>



    <div class="col-8 " style="margin-top: 100px;">
        <div class="tengah d-flex d-flex justify-content-center "
            style="margin-bottom: 20px; margin-top:-50px; margin-left: -300px;">

            <img src="../img/domba.png" alt="" style="width: 77px; height: 77px;">

            <div class="garis"
                style="width: 4px; height: 85px; background-color: black; margin-left: 5px; margin-right: 5px;">
                <p></p>
            </div>


            <h3 class="" style="margin-top: 10px; margin-left: 10px; height: 10px;">CARIBI</h3>
            <h4 class="" style="margin-top: 40px; margin-left: -120px;">Investasi</h4>



        </div>
        <div class="container">

            <div class="row justify-content-center " style="background-color: white; width: 950px;">
                <br>
                <br>
                <center>
                    <div class="row mt-4 ">
                        <a href="#" class="col-2">
                            <h4>Domba</h4>
                        </a>
                        <a href="#" class="col-2">
                            <h4>Peternakan</h4>
                        </a>
                    </div>
                    <div class="garis mb-4" style="width: 100%; height: 2px; background-color: #3A8BCD; margin-left: 5px; margin-right:
                    5px;">
                    </div>
                    <p class="mt-2">Menampilkan 20 Domba per Halaman</p>
                </center>



                <center>
                    <h4 class="mt-4">Peternakan Populer Saat Ini</h4>
                </center>
                <div class="garis" style="width: 40%; height: 2px; background-color: #3A8BCD; "></div>
                <br>


                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators1" data-slide-to="3" class="active"></li>
                        <li data-target="#carouselExampleIndicators1" data-slide-to="4"></li>
                        <li data-target="#carouselExampleIndicators1" data-slide-to="5"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="row " alt="First slide">
                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/4.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Peternakan Udin</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>
                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/5.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Sultan Domba</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>
                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/6.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Best Farm</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="row " alt="Second slide">

                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/6.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Best Farm</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>

                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/5.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Sultan Domba</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>

                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/4.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Peternakan Udin</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="row " alt="Third slide">

                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/6.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Best Farm</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>

                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/4.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Peternakan Udin</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>

                                <div class="item col">
                                    <div class="work1" style="border: 1px solid #000000; ">
                                        <div class="img d-flex align-items-center  rounded" style="background-image: url(../img/5.jpg); width: 100%;
                                height: 180px; ">
                                        </div>
                                        <div class="caption1 col-sm">
                                            <center>
                                                <h5 class=""><b>Sultan Domba</b> </h5>
                                            </center>
                                            <ul>
                                                <li><a href="#">300+</a> investor berinvestasi pada domba peternakan ini
                                                </li>
                                                <li><a href="#">Domba Garut</a> jenis paling diminati di peternakan ini
                                                </li>
                                                <li><a href="#">35%</a> rata - rata persentasi bagi hasil investor</li>
                                                <li><a href="#">100+</a> investasi domba yang berhasil</li>
                                            </ul>
                                            <center>
                                                <a class="btn btn-primary " href="pasar_detail_domba.html">Cek
                                                    Sekarang</a>
                                            </center>
                                            <br>
                                        </div>

                                    </div>
                                </div>



                            </div>

                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                            data-slide="prev"
                            style="background-color: black; width: 40px; height: 50px; margin-top: 300px;">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                            data-slide="next" style="background-color: black;width: 40px; height: 50px; margin-top:
                            300px;">
                            <span class="carousel-control-next-icon" aria-hidden="true"
                                style="background-color: black;"></span>
                        </a>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div class=" col-md-3 " style="margin-left: 30px;">


</div>
</div>



@endsection