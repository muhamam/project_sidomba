@extends('layouts.user')

@section('content')

<div class="row">
    <div class="col " style="margin-left: 30px; margin-top:180px; width: 300px;">
        <div class=" bg-light ">
            <center>
                <table>
                    <tr>
                        <td> <span><img src="../img/about-us.jpg" alt="" style="width: 85px; height:85px; "
                                    class="  ml-3 rounded-circle">
                            </span></td>
                        <td>
                            <a href="#" class="  " style="color:#000000 ;">Muhammad
                                anas
                            </a>
                            <a href="#" style="font-size:9px;color:#000000 ;">muhammadanasaiman0@gmail.com</a><br>
                            <ul class="d-flex" style="list-style-type: disc; color:red; font-size:12px;">
                                <li>
                                    <span style="color: black;">Peternakan</span>
                                </li>
                                <li class="ml-4">
                                    <span style="color: black;">Investasi</span>
                                </li>
                            </ul>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                </table>
                <div class="garis" style="width: 95%; height: 2px; background-color: black; margin-left: 5px; margin-right:
                        5px;">
                    <p></p>
                </div>
                <div class="dalam ">
                    <span class="iconify" data-icon="ic:baseline-account-box" data-width="25" data-height="25"
                        style="margin-right: 130px; margin-bottom: -60px;"></span>
                    <a href="dashboard_investor.html" class="dropdown-item ">Akun</a>
                    <span class="iconify" data-icon="bi:chat-text" data-width="25" data-height="25"
                        style="margin-right: 130px; margin-bottom: -60px;"></span>
                    <a href="pasar.html" class="dropdown-item ">Chat</a>
                    <span class="iconify" data-icon="carbon:star-review" data-width="25" data-height="25"
                        style="margin-right: 130px; margin-bottom: -60px;"></span>
                    <a href="investasi_saya_semua.html" class="dropdown-item">Ulasan</a>
                    <span class="iconify" data-icon="carbon:warning" data-width="25" data-height="25"
                        style="margin-right: 130px; margin-bottom: -60px;"></span>
                    <a href="investasi_riwayat.html" class="dropdown-item">Komplain</a>
                    <span class="iconify" data-icon="bi:list-stars" data-width="25" data-height="25"
                        style="margin-right: 130px; margin-bottom: -60px;"></span>
                    <a href="#" class="dropdown-item ml-3">Wishlist</a>
                    <span class="iconify" data-icon="carbon:money" data-width="25" data-height="25"
                        style="margin-right: 130px; margin-bottom: -60px;"></span>
                    <a href="#" class="dropdown-item ml-3 ">Transaksi</a>
                </div>

            </center>
        </div>

    </div>
    <section class="ftco-section col " style="margin-top: 95px;">
        <div class="tengah d-flex d-flex justify-content-center " style="margin-bottom: 20px; margin-top:-50px;">

            <img src="../img/domba.png" alt="" style="width: 77px; height: 77px;">

            <div class="garis"
                style="width: 4px; height: 85px; background-color: black; margin-left: 5px; margin-right: 5px;">
                <p></p>
            </div>


            <h3 class="" style="margin-top: 10px; margin-left: 10px; height: 10px;">CARIBI</h3>
            <h4 class="" style="margin-top: 40px; margin-left: -120px;">Investasi</h4>



        </div>
        <div class="container " style="background-color: white; width: 994px;">


            <div class="d-flex flex-row " style=" margin-left:20px;">
                {{-- klo diedit bawa href nya --}}
                <a class="" href="{{route('transaksi.indexDiproses')}}" style="color: #000;">
                    <h5>Diproses</h5>
                </a>
                <a class="ml-4" href="{{route('transaksi.indexMenungguPembayaran')}}" style="color: #000;">
                    <h5>Menunggu Pembayaran</h5>
                </a>
                <a class="ml-4" href="{{route('transaksi.indexSelesai')}}" style="color: #000;">
                    <h5>Selesai</h5>
                </a>
            </div>
            <div class="pb-5 " style="border:1px solid black ; padding:20px;  border-radius:20px;">
                <div class="row mb-3">
                    <a href="#" class="col-2 btn btn-outline-primary mr-3 ml-5">Pembelian</a>
                    <a href="#" class="col-2 btn btn-outline-primary">Investasi</a>
                </div>

                <div class="kabeh rounded-lg" style="border: 1px solid #000; height: 380px; ">
                    <div class="row mt-3">
                        <p class="col-3"><b> Rabu, 25 Mei 2022 </b></p>
                    </div>
                    <div class=" mb-3" style="width: 100%; height:1px; background-color: #000000; "></div>
                    <div class="row ml-5">
                        <h6 class="col-3">Peternakan Udin</h6>
                        <a href="#" class="btn btn-outline-primary rounded col-2" style="font-size: 10px;"> Sedang
                            Berlangsung</a>
                    </div>
                    <div class="row gutters-sm mt-4 ml-1">
                        <div class=" col-md-2 ">
                            <a href="btn" data-bs-toggle="modal" data-bs-target="#exampleModalinti">
                                <img class="rounded" src="../img/1.jpg" width="160px" height="180px">
                            </a>
                            <div class="modal fade mt-5" id="exampleModalinti" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <img src="../img/1.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-3 ml-5  " style="font-size:12px;">
                            <div class="row">
                                <table>
                                    <thead>
                                        <tr>
                                            <th colspan="4">
                                                <h6> Domba Suffolk </h6>
                                            </th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">ID</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>DS123</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Berat</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>23Kg</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Umur</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>3 Bulan (21/02/2022)</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Jenis Kelamin</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>Jantan </td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>

                        </div>

                        <div class="col-4 row" style="margin-left:-35px;">
                            <center>
                                <div class=" ">
                                    <h5 style="">Selesaikan Pembayaran Dalam</h5>
                                    <h4 style="border: 1px solid black; border-radius:30px;"><a class="ml-3" href="#"
                                            style="color:#F77E21;">22 : 30 : 00</a>
                                    </h4>
                                </div>
                                <div class=" ">
                                    <h5 style="">Nominal Investasi</h5>
                                    <h4><a class="ml-3" href="#" style="color:#3A8BCD;">Rp1.450.000,00</a>
                                    </h4>
                                </div>
                            </center>
                        </div>


                        <div class="col-3 " style="padding:0;">
                            <div class="">
                                <div class="col-11">
                                    <center>
                                        <div class="" style="border: 1px solid black; border-radius:20px;">
                                            <span class="iconify" data-icon="icon-park-outline:disabled-picture"
                                                data-width="70" data-height="70"></span>
                                            <h3><a class="ml-1" href="#"
                                                    style=" font-size:15px; color:rgb(60, 255, 0);">Anda belum
                                                    mengajukan bukti transfer</a>
                                            </h3>
                                        </div>

                                        <!-- Button trigger modal -->
                                        <a type="button" href="#" class="btn btn-primary mt-3" data-toggle="modal"
                                            data-target="#exampleModal-1" style="">Detail</a>
                                    </center>
                                </div>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal-1" aria-labelledby="exampleModalLabel">
                                    <div class="modal-dialog">
                                        <div class="modal-content">

                                            <div class="modal-body">
                                                <div class="row justify-content-center ml-3 modal-title"
                                                    id="exampleModalLabel">
                                                    <div class="row gutters-sm mt-2">
                                                        <div class="" style="width:100px; height:300px;">
                                                            <div class="">
                                                                <div class="">
                                                                    <div class="">
                                                                        <a href="btn" data-bs-toggle="modal"
                                                                            data-bs-target="#exampleModalinti">
                                                                            <img class="rounded" src="../img/1.jpg"
                                                                                width="200px" height="200px">
                                                                        </a>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="">

                                                            <div class=" "
                                                                style="margin-left: 250px; margin-top:-320px;">
                                                                <h4>Domba Suffolk</h4>
                                                                <h5>Data Domba</h5>
                                                                <div class="row">
                                                                    <table>
                                                                        <thead>
                                                                            <tr>
                                                                                <th scope="col"></th>
                                                                                <th scope="col"></th>
                                                                                <th scope="col"></th>
                                                                                <th scope="col"></th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <th scope="row">ID</th>
                                                                                <td></td>
                                                                                <td>:</td>
                                                                                <td>DS123</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th scope="row">Berat</th>
                                                                                <td></td>
                                                                                <td>:</td>
                                                                                <td>23Kg</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th scope="row">Umur</th>
                                                                                <td></td>
                                                                                <td>:</td>
                                                                                <td>3 Bulan (21/02/2022)</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th scope="row">Jenis Kelamin
                                                                                </th>
                                                                                <td></td>
                                                                                <td>:</td>
                                                                                <td>Jantan </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <div class=""
                                                                        style="width: 100%; height:1px; background-color: #3A8BCD;">
                                                                    </div>
                                                                    <div class="D">
                                                                        <h5>Data
                                                                            Peternakan</h5>
                                                                        <a href="#">Peternakan
                                                                            Udin</a>
                                                                        <p class="">
                                                                            Soreang, Bandung
                                                                        </p>
                                                                        <span class="iconify"
                                                                            data-icon="flat-color-icons:rating"
                                                                            data-width="25" data-height="25"></span>
                                                                        <span class="iconify"
                                                                            data-icon="flat-color-icons:rating"
                                                                            data-width="25" data-height="25"></span>
                                                                        <span class="iconify"
                                                                            data-icon="flat-color-icons:rating"
                                                                            data-width="25" data-height="25"></span>
                                                                        <span class="iconify"
                                                                            data-icon="flat-color-icons:rating"
                                                                            data-width="25" data-height="25"></span>
                                                                        <span class="iconify"
                                                                            data-icon="flat-color-icons:rating"
                                                                            data-width="25" data-height="25"></span>
                                                                        <br>
                                                                        <a href="#(link menju peternak)">Lihat
                                                                            Peternakan</a>
                                                                    </div>


                                                                </div>


                                                            </div>


                                                        </div>

                                                        <div class="d-flex justify-content-between">
                                                            <div class="q rounded-lg"
                                                                style="width:180px ; border: 1px solid #000;">
                                                                <center>
                                                                    <p>Harga Jual</p>
                                                                    <h6>Rp3.700.000,00</h6>
                                                                </center>
                                                            </div>
                                                            <div class="q rounded-lg "
                                                                style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                                <center>
                                                                    <p>Bagi Hasil</p>
                                                                    <h6>50%</h6>
                                                                </center>
                                                            </div>

                                                        </div>
                                                        <div class="d-flex justify-content-between mt-5">
                                                            <div class="q rounded-lg"
                                                                style="width:180px ; border: 1px solid #000;">
                                                                <center>
                                                                    <p>Keuntungan</p>
                                                                    <h6>Rp1.850.000,00</h6>
                                                                </center>
                                                            </div>
                                                            <div class="q rounded-lg "
                                                                style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                                <center>
                                                                    <p>Laba Bersih</p>
                                                                    <a href="#">
                                                                        <h6 style="color: rgb(0, 255, 0);">
                                                                            Rp400.000,00</h6>
                                                                    </a>
                                                                </center>
                                                            </div>

                                                        </div>
                                                        <br>

                                                        <div class=" "
                                                            style="width: 95%; height: 2px; background-color: #3A8BCD;margin-top: -190px;">
                                                        </div>
                                                        <center>
                                                            <div class="mt-4">
                                                                <h5 style="margin-left:120px;"><b> Nominasi
                                                                        Investasi</b></h5>
                                                                <h3 style="margin-left:120px;"><a
                                                                        href="#">Rp1.450.000,00</a></h3>
                                                            </div>
                                                        </center>

                                                        <div class=" "
                                                            style="width: 95%; height: 2px; background-color: #3A8BCD;">
                                                        </div>
                                                        <br>

                                                    </div>

                                                </div>
                                            </div>
                                            <center>
                                                <button type="button" class="btn btn-secondary mb-3"
                                                    data-dismiss="modal">Close</button>
                                            </center>
                                        </div>
                                    </div>

                                </div>
                                <!-- modal end -->
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="kabeh rounded-lg" style="border: 1px solid #000; height: 380px; ">
                    <div class="row mt-3">
                        <p class="col-3"><b> Rabu, 25 Mei 2022 </b></p>
                    </div>
                    <div class=" mb-3" style="width: 100%; height:1px; background-color: #000000; "></div>
                    <div class="row ml-5">
                        <h6 class="col-3">Peternakan Udin</h6>
                        <a href="#" class="btn btn-outline-primary rounded col-2" style="font-size: 10px;"> Sedang
                            Berlangsung</a>
                    </div>
                    <div class="row gutters-sm mt-4 ml-1">
                        <div class=" col-md-2 ">
                            <a href="btn" data-bs-toggle="modal" data-bs-target="#exampleModalinti">
                                <img class="rounded" src="../img/1.jpg" width="160px" height="180px">
                            </a>
                            <div class="modal fade mt-5" id="exampleModalinti" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <img src="../img/1.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 ml-5  " style="font-size:12px ;">
                            <div class="row">
                                <table>
                                    <thead>
                                        <tr>
                                            <th colspan="4">
                                                <h6> Domba Suffolk </h6>
                                            </th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">ID</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>DS123</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Berat</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>23Kg</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Umur</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>3 Bulan (21/02/2022)</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Jenis Kelamin</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>Jantan </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-4 row" style="margin-left:-35px;">
                            <center>
                                <div class=" ">
                                    <h5 style="">Status Pembayaran</h5>
                                    <h4 style=" border-radius:30px; width:100%;" class="btn btn-danger"><a href="#"
                                            style="color:white;">Tidak Valid</a>
                                    </h4>
                                </div>
                                <div class=" ">
                                    <h5 style="">Harap ajukan bukti transfer lain yang valid dalam</h5>
                                    <h4 style="border: 1px solid black; border-radius:30px;"><a class="ml-3" href="#"
                                            style="color:black;">22 : 30 : 00</a>
                                </div>
                            </center>
                        </div>


                        <div class="col-3 " style="padding:0;">
                            <div class="col-11">
                                <center>
                                    <div class="" style="">
                                        <img src="../img/transaksi.jpg" alt="" width="180px" height="100px"
                                            style="border-radius: 15px;">
                                        <h6><a class=" ml-1" href="#" style=" ">
                                                Bukti Transfer yang diajukan
                                            </a>
                                        </h6>
                                    </div>

                                    <!-- Button trigger modal -->
                                    <a type="button" href="#" class="btn btn-primary mt-3" data-toggle="modal"
                                        data-target="#exampleModal-1" style="">Detail</a>
                                </center>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal-1" aria-labelledby="exampleModalLabel">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <div class="modal-body">
                                            <div class="row justify-content-center ml-3 modal-title"
                                                id="exampleModalLabel">
                                                <div class="row gutters-sm mt-2">
                                                    <div class="" style="width:100px; height:300px;">
                                                        <div class="">
                                                            <div class="">
                                                                <div class="">
                                                                    <a href="btn" data-bs-toggle="modal"
                                                                        data-bs-target="#exampleModalinti">
                                                                        <img class="rounded" src="../img/1.jpg"
                                                                            width="200px" height="200px">
                                                                    </a>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="">

                                                        <div class=" " style="margin-left: 250px; margin-top:-320px;">
                                                            <h4>Domba Suffolk</h4>
                                                            <h5>Data Domba</h5>
                                                            <div class="row">
                                                                <table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <th scope="row">ID</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>DS123</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Berat</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>23Kg</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Umur</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>3 Bulan (21/02/2022)</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Jenis Kelamin
                                                                            </th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>Jantan </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <div class=""
                                                                    style="width: 100%; height:1px; background-color: #3A8BCD;">
                                                                </div>
                                                                <div class="D">
                                                                    <h5>Data
                                                                        Peternakan</h5>
                                                                    <a href="#">Peternakan
                                                                        Udin</a>
                                                                    <p class="">
                                                                        Soreang, Bandung
                                                                    </p>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <br>
                                                                    <a href="#(link menju peternak)">Lihat
                                                                        Peternakan</a>
                                                                </div>


                                                            </div>


                                                        </div>


                                                    </div>

                                                    <div class="d-flex justify-content-between">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Harga Jual</p>
                                                                <h6>Rp3.700.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Bagi Hasil</p>
                                                                <h6>50%</h6>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <div class="d-flex justify-content-between mt-5">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Keuntungan</p>
                                                                <h6>Rp1.850.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Laba Bersih</p>
                                                                <a href="#">
                                                                    <h6 style="color: rgb(0, 255, 0);">
                                                                        Rp400.000,00</h6>
                                                                </a>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <br>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;margin-top: -190px;">
                                                    </div>
                                                    <center>
                                                        <div class="mt-4">
                                                            <h5 style="margin-left:120px;"><b> Nominasi
                                                                    Investasi</b></h5>
                                                            <h3 style="margin-left:120px;"><a
                                                                    href="#">Rp1.450.000,00</a></h3>
                                                        </div>
                                                    </center>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;">
                                                    </div>
                                                    <br>

                                                </div>

                                            </div>
                                        </div>
                                        <center>
                                            <button type="button" class="btn btn-secondary mb-3"
                                                data-dismiss="modal">Close</button>
                                        </center>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="kabeh rounded-lg" style="border: 1px solid #000; height: 380px; ">
                    <div class="row mt-3">
                        <p class="col-3"><b> Rabu, 25 Mei 2022 </b></p>
                    </div>
                    <div class=" mb-3" style="width: 100%; height:1px; background-color: #000000; "></div>
                    <div class="row ml-5">
                        <h6 class="col-3">Peternakan Udin</h6>
                        <a href="#" class="btn btn-outline-primary rounded col-2" style="font-size: 10px;"> Sedang
                            Berlangsung</a>
                    </div>
                    <div class="row gutters-sm mt-4 ml-1">
                        <div class=" col-md-2 ">
                            <a href="btn" data-bs-toggle="modal" data-bs-target="#exampleModalinti">
                                <img class="rounded" src="../img/1.jpg" width="160px" height="180px">
                            </a>
                            <div class="modal fade mt-5" id="exampleModalinti" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <img src="../img/1.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 ml-5  " style="font-size:12px ;">
                            <div class="row">
                                <table>
                                    <thead>
                                        <tr>
                                            <th colspan="4">
                                                <h6> Domba Suffolk </h6>
                                            </th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">ID</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>DS123</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Berat</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>23Kg</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Umur</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>3 Bulan (21/02/2022)</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Jenis Kelamin</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>Jantan </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-4 row" style="margin-left:-35px;">
                            <center>
                                <div>
                                    <h5>Status Pembayaran</h5>
                                    <h4 style=" border-radius:30px; width:100%;" class="btn btn-primary"><a href="#"
                                            style="color:white;">Sedang Diverifikas</a>
                                </div>
                                <div>
                                    <h5><a href="#">Nominal Pembayaran</a></h5>
                                    <h4><a class="ml-3" href="#" style="color:#3A8BCD;">Rp1.450.000,00</a>
                                    </h4>
                                </div>
                            </center>
                        </div>


                        <div class="col-3 " style="padding:0;">
                            <div class="col-11">
                                <center>
                                    <div class="">
                                        <img src="../img/transaksi.jpg" alt="" width="180px" height="100px"
                                            style="border-radius: 15px;">
                                        <h6><a class=" ml-1" href="#" style=" ">
                                                Bukti Transfer yang diajukan
                                            </a>
                                        </h6>
                                    </div>

                                    <!-- Button trigger modal -->
                                    <a type="button" href="#" class="btn btn-primary mt-3" data-toggle="modal"
                                        data-target="#exampleModal-1" style="">Detail</a>
                                </center>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal-1" aria-labelledby="exampleModalLabel">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <div class="modal-body">
                                            <div class="row justify-content-center ml-3 modal-title"
                                                id="exampleModalLabel">
                                                <div class="row gutters-sm mt-2">
                                                    <div class="" style="width:100px; height:300px;">
                                                        <div class="">
                                                            <div class="">
                                                                <div class="">
                                                                    <a href="btn" data-bs-toggle="modal"
                                                                        data-bs-target="#exampleModalinti">
                                                                        <img class="rounded" src="../img/1.jpg"
                                                                            width="200px" height="200px">
                                                                    </a>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="">

                                                        <div class=" " style="margin-left: 250px; margin-top:-320px;">
                                                            <h4>Domba Suffolk</h4>
                                                            <h5>Data Domba</h5>
                                                            <div class="row">
                                                                <table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <th scope="row">ID</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>DS123</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Berat</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>23Kg</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Umur</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>3 Bulan (21/02/2022)</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Jenis Kelamin
                                                                            </th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>Jantan </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <div class=""
                                                                    style="width: 100%; height:1px; background-color: #3A8BCD;">
                                                                </div>
                                                                <div class="D">
                                                                    <h5>Data
                                                                        Peternakan</h5>
                                                                    <a href="#">Peternakan
                                                                        Udin</a>
                                                                    <p class="">
                                                                        Soreang, Bandung
                                                                    </p>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <br>
                                                                    <a href="#(link menju peternak)">Lihat
                                                                        Peternakan</a>
                                                                </div>


                                                            </div>


                                                        </div>


                                                    </div>

                                                    <div class="d-flex justify-content-between">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Harga Jual</p>
                                                                <h6>Rp3.700.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Bagi Hasil</p>
                                                                <h6>50%</h6>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <div class="d-flex justify-content-between mt-5">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Keuntungan</p>
                                                                <h6>Rp1.850.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Laba Bersih</p>
                                                                <a href="#">
                                                                    <h6 style="color: rgb(0, 255, 0);">
                                                                        Rp400.000,00</h6>
                                                                </a>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <br>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;margin-top: -190px;">
                                                    </div>
                                                    <center>
                                                        <div class="mt-4">
                                                            <h5 style="margin-left:120px;"><b> Nominasi
                                                                    Investasi</b></h5>
                                                            <h3 style="margin-left:120px;"><a
                                                                    href="#">Rp1.450.000,00</a></h3>
                                                        </div>
                                                    </center>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;">
                                                    </div>
                                                    <br>

                                                </div>

                                            </div>
                                        </div>
                                        <center>
                                            <button type="button" class="btn btn-secondary mb-3"
                                                data-dismiss="modal">Close</button>
                                        </center>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="kabeh rounded-lg" style="border: 1px solid #000; height: 380px; ">
                    <div class="row mt-3">
                        <p class="col-3"><b> Rabu, 25 Mei 2022 </b></p>
                    </div>
                    <div class=" mb-3" style="width: 100%; height:1px; background-color: #000000; "></div>
                    <div class="row ml-5">
                        <h6 class="col-3">Peternakan Udin</h6>
                        <a href="#" class="btn btn-outline-primary rounded col-2" style="font-size: 10px;"> Sedang
                            Berlangsung</a>
                    </div>
                    <div class="row gutters-sm mt-4 ml-1">
                        <div class=" col-md-2 ">
                            <a href="btn" data-bs-toggle="modal" data-bs-target="#exampleModalinti">
                                <img class="rounded" src="../img/1.jpg" width="160px" height="180px">
                            </a>
                            <div class="modal fade mt-5" id="exampleModalinti" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <img src="../img/1.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 ml-5  " style="font-size:12px ;">
                            <div class="row">
                                <table>
                                    <thead>
                                        <tr>
                                            <th colspan="4">
                                                <h6> Domba Suffolk </h6>
                                            </th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">ID</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>DS123</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Berat</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>23Kg</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Umur</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>3 Bulan (21/02/2022)</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Jenis Kelamin</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>Jantan </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-4 row" style="margin-left:-35px;">
                            <center>
                                <div class=" ">
                                    <h5 style="">Status Pembayaran</h5>
                                    <h4 style=" border-radius:30px; width:100%;" class="btn btn-success"><a href="#"
                                            style="color:white;">Valid</a>
                                    </h4>
                                </div>
                                <div class=" ">
                                    <h5 style="">Nominal Investasi</h5>
                                    <h4><a class="ml-3" href="#" style="color:#3A8BCD;">Rp1.450.000,00</a>
                                    </h4>
                                </div>
                            </center>
                        </div>


                        <div class="col " style="padding:0;">
                            <div class="col-11">
                                <center>
                                    <div class="col-12" style=" border:1px solid black; border-radius:15px;">
                                        <p>Selamat! Transaksi Anda telah berhasil divalidasi. Silahkan pantau investasi
                                            Anda pada menu Investasi Saya > Berjalan</p>
                                    </div>

                                    <!-- Button trigger modal -->
                                    <a type="button" href="#" class="btn btn-primary mt-3" data-toggle="modal"
                                        data-target="#exampleModal-1" style="">Detail</a>
                                </center>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal-1" aria-labelledby="exampleModalLabel">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <div class="modal-body">
                                            <div class="row justify-content-center ml-3 modal-title"
                                                id="exampleModalLabel">
                                                <div class="row gutters-sm mt-2">
                                                    <div class="" style="width:100px; height:300px;">
                                                        <div class="">
                                                            <div class="">
                                                                <div class="">
                                                                    <a href="btn" data-bs-toggle="modal"
                                                                        data-bs-target="#exampleModalinti">
                                                                        <img class="rounded" src="../img/1.jpg"
                                                                            width="200px" height="200px">
                                                                    </a>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="">

                                                        <div class=" " style="margin-left: 250px; margin-top:-320px;">
                                                            <h4>Domba Suffolk</h4>
                                                            <h5>Data Domba</h5>
                                                            <div class="row">
                                                                <table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <th scope="row">ID</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>DS123</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Berat</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>23Kg</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Umur</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>3 Bulan (21/02/2022)</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Jenis Kelamin
                                                                            </th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>Jantan </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <div class=""
                                                                    style="width: 100%; height:1px; background-color: #3A8BCD;">
                                                                </div>
                                                                <div class="D">
                                                                    <h5>Data
                                                                        Peternakan</h5>
                                                                    <a href="#">Peternakan
                                                                        Udin</a>
                                                                    <p class="">
                                                                        Soreang, Bandung
                                                                    </p>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <br>
                                                                    <a href="#(link menju peternak)">Lihat
                                                                        Peternakan</a>
                                                                </div>


                                                            </div>


                                                        </div>


                                                    </div>

                                                    <div class="d-flex justify-content-between">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Harga Jual</p>
                                                                <h6>Rp3.700.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Bagi Hasil</p>
                                                                <h6>50%</h6>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <div class="d-flex justify-content-between mt-5">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Keuntungan</p>
                                                                <h6>Rp1.850.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Laba Bersih</p>
                                                                <a href="#">
                                                                    <h6 style="color: rgb(0, 255, 0);">
                                                                        Rp400.000,00</h6>
                                                                </a>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <br>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;margin-top: -190px;">
                                                    </div>
                                                    <center>
                                                        <div class="mt-4">
                                                            <h5 style="margin-left:120px;"><b> Nominasi
                                                                    Investasi</b></h5>
                                                            <h3 style="margin-left:120px;"><a
                                                                    href="#">Rp1.450.000,00</a></h3>
                                                        </div>
                                                    </center>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;">
                                                    </div>
                                                    <br>

                                                </div>

                                            </div>
                                        </div>
                                        <center>
                                            <button type="button" class="btn btn-secondary mb-3"
                                                data-dismiss="modal">Close</button>
                                        </center>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="kabeh rounded-lg" style="border: 1px solid #000; height: 380px; ">
                    <div class="row mt-3">
                        <p class="col-3"><b> Rabu, 25 Mei 2022 </b></p>
                    </div>
                    <div class=" mb-3" style="width: 100%; height:1px; background-color: #000000; "></div>
                    <div class="row ml-5">
                        <h6 class="col-3">Peternakan Udin</h6>
                        <a href="#" class="btn btn-outline-primary rounded col-2" style="font-size: 10px;"> Sedang
                            Berlangsung</a>
                    </div>
                    <div class="row gutters-sm mt-4 ml-1">
                        <div class=" col-md-2 ">
                            <a href="btn" data-bs-toggle="modal" data-bs-target="#exampleModalinti">
                                <img class="rounded" src="../img/1.jpg" width="160px" height="180px">
                            </a>
                            <div class="modal fade mt-5" id="exampleModalinti" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <img src="../img/1.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 ml-5  " style="font-size:12px ;">
                            <div class="row">
                                <table>
                                    <thead>
                                        <tr>
                                            <th colspan="4">
                                                <h6> Domba Suffolk </h6>
                                            </th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">ID</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>DS123</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Berat</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>23Kg</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Umur</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>3 Bulan (21/02/2022)</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Jenis Kelamin</th>
                                            <td></td>
                                            <td>:</td>
                                            <td>Jantan </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-4 row" style="margin-left:-35px;">
                            <center>
                                <div class=" ">
                                    <h5 style="">Status Pembayaran</h5>
                                    <h4 style=" border-radius:30px; width:100%;" class="btn btn-warning"><a href="#"
                                            style="color:white;">Kadaluarsa</a>
                                </div>
                                <div class=" ">
                                    <h5 style="">Nominal Investasi</h5>
                                    <h4><a class="ml-3" href="#" style="color:#3A8BCD;">Rp1.450.000,00</a>
                                    </h4>
                                </div>
                            </center>
                        </div>


                        <div class="col-3 " style="padding:0;">
                            <div class="col-11">
                                <center>
                                    <div class="" style="border:1px solid black; border-radius:15px;">
                                        <p>
                                            Maaf, waktu pembayaran transaksi Anda telah habis. Silahkan mencari
                                            investasi lainnya pada menu Pasar
                                        </p>
                                    </div>

                                    <!-- Button trigger modal -->
                                    <a type="button" href="#" class="btn btn-primary mt-3" data-toggle="modal"
                                        data-target="#exampleModal-1" style="">Detail</a>
                                </center>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal-1" aria-labelledby="exampleModalLabel">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                        <div class="modal-body">
                                            <div class="row justify-content-center ml-3 modal-title"
                                                id="exampleModalLabel">
                                                <div class="row gutters-sm mt-2">
                                                    <div class="" style="width:100px; height:300px;">
                                                        <div class="">
                                                            <div class="">
                                                                <div class="">
                                                                    <a href="btn" data-bs-toggle="modal"
                                                                        data-bs-target="#exampleModalinti">
                                                                        <img class="rounded" src="../img/1.jpg"
                                                                            width="200px" height="200px">
                                                                    </a>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="">

                                                        <div class=" " style="margin-left: 250px; margin-top:-320px;">
                                                            <h4>Domba Suffolk</h4>
                                                            <h5>Data Domba</h5>
                                                            <div class="row">
                                                                <table>
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                            <th scope="col"></th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <th scope="row">ID</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>DS123</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Berat</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>23Kg</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Umur</th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>3 Bulan (21/02/2022)</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Jenis Kelamin
                                                                            </th>
                                                                            <td></td>
                                                                            <td>:</td>
                                                                            <td>Jantan </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <div class=""
                                                                    style="width: 100%; height:1px; background-color: #3A8BCD;">
                                                                </div>
                                                                <div class="D">
                                                                    <h5>Data
                                                                        Peternakan</h5>
                                                                    <a href="#">Peternakan
                                                                        Udin</a>
                                                                    <p class="">
                                                                        Soreang, Bandung
                                                                    </p>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <span class="iconify"
                                                                        data-icon="flat-color-icons:rating"
                                                                        data-width="25" data-height="25"></span>
                                                                    <br>
                                                                    <a href="#(link menju peternak)">Lihat
                                                                        Peternakan</a>
                                                                </div>


                                                            </div>


                                                        </div>


                                                    </div>

                                                    <div class="d-flex justify-content-between">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Harga Jual</p>
                                                                <h6>Rp3.700.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Bagi Hasil</p>
                                                                <h6>50%</h6>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <div class="d-flex justify-content-between mt-5">
                                                        <div class="q rounded-lg"
                                                            style="width:180px ; border: 1px solid #000;">
                                                            <center>
                                                                <p>Keuntungan</p>
                                                                <h6>Rp1.850.000,00</h6>
                                                            </center>
                                                        </div>
                                                        <div class="q rounded-lg "
                                                            style="width:180px ; border: 1px solid #000; margin-left: 100px;">
                                                            <center>
                                                                <p>Laba Bersih</p>
                                                                <a href="#">
                                                                    <h6 style="color: rgb(0, 255, 0);">
                                                                        Rp400.000,00</h6>
                                                                </a>
                                                            </center>
                                                        </div>

                                                    </div>
                                                    <br>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;margin-top: -190px;">
                                                    </div>
                                                    <center>
                                                        <div class="mt-4">
                                                            <h5 style="margin-left:120px;"><b> Nominasi
                                                                    Investasi</b></h5>
                                                            <h3 style="margin-left:120px;"><a
                                                                    href="#">Rp1.450.000,00</a></h3>
                                                        </div>
                                                    </center>

                                                    <div class=" "
                                                        style="width: 95%; height: 2px; background-color: #3A8BCD;">
                                                    </div>
                                                    <br>

                                                </div>

                                            </div>
                                        </div>
                                        <center>
                                            <button type="button" class="btn btn-secondary mb-3"
                                                data-dismiss="modal">Close</button>
                                        </center>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <br>
            </div>
            <br>
        </div>

    </section>
</div>

@endsection