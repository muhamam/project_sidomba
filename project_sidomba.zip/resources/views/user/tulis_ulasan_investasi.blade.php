@extends('layouts.user')

@section('content')

<div class="row">
    @include('layouts.sidebarUser')
    <section class="ftco-section col " style="margin-top: 95px;">
        <div class="tengah d-flex d-flex justify-content-center " style="margin-bottom: 20px; margin-top:-50px;">

            <img src="../img/domba.png" alt="" style="width: 77px; height: 77px;">

            <div class="garis"
                style="width: 4px; height: 85px; background-color: black; margin-left: 5px; margin-right: 5px;">
                <p></p>
            </div>


            <h3 class="" style="margin-top: 10px; margin-left: 10px; height: 10px;">CARIBI</h3>
            <h4 class="" style="margin-top: 40px; margin-left: -120px;">Investasi</h4>



        </div>
        <div class="container " style="background-color: white; width: 994px;">


            <div class="d-flex flex-row " style=" margin-left:20px;">
                <a class="" href="investasi_riwayat.html" style="color: #000;">
                    <h5>Belum Diulas</h5>
                </a>
                <a class="ml-4" href="investasi_negosiasi.html" style="color: #000;">
                    <h5>Ulasan Saya</h5>
                </a>
            </div>

            <div class="kabeh rounded-lg" style="border: 1px solid #000; ">
                <div class="row mt-3">
                    <p class="col-3 ml-4 " style="border-right:1px solid black ; "><b>Invoice :
                            INV/001/052022 </b> </p>

                    <p class="col-3"><b> Rabu, 25 Mei 2022 </b></p>
                </div>
                <div class=" mb-3" style="width: 100%; height:1px; background-color: #000000; "></div>
                <div class="row ml-5">
                    <h6 class="col-3">Peternakan Udin</h6>
                    <a href="#" class="btn btn-outline-primary rounded col-3" style="font-size: 15px;"> Selesai</a>
                </div>
                <div class="row gutters-sm mt-4 ml-1">
                    <div class=" col-md-2 ">
                        <a href="btn" data-bs-toggle="modal" data-bs-target="#exampleModalinti">
                            <img class="rounded" src="../img/1.jpg" width="160px" height="180px">
                        </a>
                        <div class="modal fade mt-5" id="exampleModalinti" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <img src="../img/1.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-3 ml-5  " style="font-size:12px;">
                        <div class="row">
                            <table>
                                <thead>
                                    <tr>
                                        <th colspan="4">
                                            <h6> Domba Suffolk </h6>
                                        </th>
                                        <th scope="col"></th>
                                        <th scope="col"></th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">ID</th>
                                        <td></td>
                                        <td>:</td>
                                        <td>DS123</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Berat</th>
                                        <td></td>
                                        <td>:</td>
                                        <td>23Kg</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Umur</th>
                                        <td></td>
                                        <td>:</td>
                                        <td>3 Bulan (21/02/2022)</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Jenis Kelamin</th>
                                        <td></td>
                                        <td>:</td>
                                        <td>Jantan </td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>

                    </div>

                    <div class="col-3" style="  ">
                        <table>
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th colspan="3">
                                        <h6 style="">Data Peternakan</h6>
                                    </th>

                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th colspan="4"> <a href="#">Peternakan Udin</a></th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th colspan="4">
                                        <p class=""> Soreang, Bandung
                                        </p>
                                    </th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th colspan="4">
                                        <a href="#"> 500+ </a>Investasi
                                        berhasil
                                    </th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th colspan="4">
                                        <a href="#">1k</a> Domba Telah
                                        Terjual
                                    </th>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                            </tbody>
                        </table>
                    </div>


                    <div class="col-2 " style="padding:0;">
                        <div class="">
                            <div class="">
                                <center>
                                    <h6 class=""><b> Laba</b></h6>

                                    <h3><a class="" href="#"
                                            style=" font-size:15px; color:rgb(60, 255, 0);">Rp1.450.000,00</a>
                                    </h3>
                                </center>
                            </div>
                        </div>
                    </div>

                    <center>
                        <div class="dotted mt-5 col-md-12 "></div>
                    </center>
                    <div class="">
                        <h6>Bagaimana penilaian Anda terhadap Domba Ini?</h6>
                        <h6>(rating belum ada)</h6>

                        <div class="form-group mr-3">
                            <h6>Berikan ulasan Anda mengenai Domba yang telah dibeli :</h6>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                placeholder="Tulis Ulasan Anda Di sini"></textarea>
                        </div>
                        <div class="d-flex justify-content-end mr-5 mb-5">
                            <a href="#" class="btn btn-outline-primary col-2 ml-5 mr-3">Batal</a>
                            <a href="#" class="btn btn-primary col-2 ">Kirim Ulasan</a>
                        </div>
                    </div>

                </div>

            </div>
            <br>


            <br>
        </div>

    </section>
</div>

@endsection