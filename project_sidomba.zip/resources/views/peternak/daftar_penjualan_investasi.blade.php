@extends('layouts.user')

@section('content')

<br>
<div class="tu col-md-12 text-center mt-5">
    <h1> PENJUALAN DAN INVESTASI </h1>
</div>
<div class="col ">
    <div class="satu text-center ">
        <div class="">

            <h5 class=" ml-4 mt-2" style="border-bottom: 2px solid #000; width: 80%;"><b>Daftar Domba Jualan</b></h5>
            <h5>Domba yang Dijual</h5>
            <h6><b>3 Ekor</b></h6>
            <p class=" ml-2 " style="border-top: 2px solid #000; width: 90%;">Terakhir di-update 06/04/2022,
                17.30</a>


                <a href="">klik untuk info lebih lanjut</a>


        </div>
    </div>
    <div class="dua  text-center">
        <div class="">

            <h5 class=" ml-4" style="border-bottom: 2px solid #000; width: 80%;"><b>Domba Terjual</b></h5>
            <h5>Domba yang Dijual</h5>
            <h6><b>3 Ekor</b></h6>
            <p class=" ml-2 " style="border-top: 2px solid #000; width: 90%;">Terakhir di-update 06/04/2022,
                17.30</a>
                <a href="">klik untuk info lebih lanjut</a>
        </div>
    </div>
    <div class="tiga  text-center">
        <div class="">

            <h5 class=" ml-4" style="border-bottom: 2px solid #000; width: 80%;"><b>Daftar Pesanan</b></h5>
            <h5>Domba yang Dijual</h5>
            <h6><b>3 Ekor</b></h6>
            <p class=" ml-2 " style="border-top: 2px solid #000; width: 90%;">Terakhir di-update 06/04/2022,
                17.30</a>

                <a href="">klik untuk info lebih lanjut</a>
        </div>
    </div>
    <div class="empat mt-5  text-center">
        <div class="">

            <h5 class=" ml-4" style="border-bottom: 2px solid #000; width: 80%; font-size: 18px;"><b>Daftar Domba
                    Investasi</b></h5>
            <h5>Domba yang Dijual</h5>
            <h6><b>3 Ekor</b></h6>
            <p class=" ml-2 " style="border-top: 2px solid #000; width: 90%;">Terakhir di-update 06/04/2022,
                17.30</a>
                <a href="">klik untuk info lebih lanjut</a>
        </div>
    </div>

    <div class="lima  text-center">
        <div class="">

            <h6 class=" ml-3" style="border-bottom: 2px solid #000; width: 90%; font-size: 18px;"><b>Daftar
                    Investor
                    Peternakan</b></h6>
            <h5>Domba yang Dijual</h5>
            <h6><b>3 Ekor</b></h6>
            <p class=" ml-2 " style="border-top: 2px solid #000; width: 90%;">Terakhir di-update 06/04/2022,
                17.30</a>
                <a href="">klik untuk info lebih lanjut</a>

        </div>
    </div>
</div>
@endsection