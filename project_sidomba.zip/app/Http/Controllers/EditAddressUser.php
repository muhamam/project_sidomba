<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EditAddressUser extends Controller
{
    //
    public function index()
    {
        return view('user.alamat_edit ');
    }
}
