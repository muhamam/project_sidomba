<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AktivasiInvestor extends Controller
{
    //
    public function index()
    {
        return view('user.aktivasi_investor');
    }
}
